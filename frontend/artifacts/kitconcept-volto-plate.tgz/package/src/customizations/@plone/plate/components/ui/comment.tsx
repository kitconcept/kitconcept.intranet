import * as React from 'react';

import type { CreatePlateEditorOptions } from 'platejs/react';

import { getCommentKey, getDraftCommentKey } from '@platejs/comment';
import { CommentPlugin, useCommentId } from '@platejs/comment/react';
import {
  CheckIcon,
  MoreHorizontalIcon,
  PencilIcon,
  SendIcon,
  TrashIcon,
  XIcon,
} from 'lucide-react';
import { type Value, KEYS, nanoid, NodeApi } from 'platejs';
import {
  Plate,
  useEditorPlugin,
  useEditorRef,
  usePlateEditor,
} from 'platejs/react';

import { Button } from '@plone/plate/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@plone/plate/components/ui/dropdown-menu';
import { cn } from '@plone/plate/lib/utils';
import { usePlatePlugins } from '@plone/plate/components/editor/plate-plugins-context';
import { BasicMarksKit } from '@plone/plate/components/editor/plugins/basic-marks-kit';
import { type TDiscussion } from '@plone/plate/components/editor/plugins/discussion-kit';

import { Editor, EditorContainer } from '@plone/plate/components/ui/editor';

// === START CUSTOMIZATION ===
// Customization of @plone/plate's components/ui/comment.tsx:
// render the comment author with the shared PersonPill component
// instead of the Avatar/AvatarFallback initial-letter avatar.
import PersonPill from '@kitconcept/volto-plate/components/PersonPill/PersonPill';
// === END CUSTOMIZATION ===

export interface TComment {
  id: string;
  contentRich: Value;
  createdAt: Date;
  discussionId: string;
  isEdited: boolean;
  userId: string;
}

export function Comment(props: {
  comment: TComment;
  discussionLength: number;
  editingId: string | null;
  index: number;
  setEditingId: React.Dispatch<React.SetStateAction<string | null>>;
  documentContent?: string;
  showDocumentContent?: boolean;
  onEditorClick?: () => void;
  onReply?: () => void;
}) {
  const {
    comment,
    discussionLength,
    documentContent,
    editingId,
    index,
    setEditingId,
    showDocumentContent = false,
    onEditorClick,
    onReply,
  } = props;

  const { discussions, setDiscussions, users, currentUserId } =
    usePlatePlugins();
  const userInfo = users[comment.userId];

  const resolveDiscussion = async (id: string) => {
    const updatedDiscussions = discussions.map((discussion) => {
      if (discussion.id === id) {
        return { ...discussion, isResolved: true };
      }
      return discussion;
    });
    setDiscussions(updatedDiscussions);
  };

  const removeDiscussion = async (id: string) => {
    const updatedDiscussions = discussions.filter(
      (discussion) => discussion.id !== id,
    );
    setDiscussions(updatedDiscussions);
  };

  const updateComment = async (input: {
    id: string;
    contentRich: Value;
    discussionId: string;
    isEdited: boolean;
  }) => {
    const updatedDiscussions = discussions.map((discussion) => {
      if (discussion.id === input.discussionId) {
        const updatedComments = discussion.comments.map((comment) => {
          if (comment.id === input.id) {
            return {
              ...comment,
              contentRich: input.contentRich,
              isEdited: true,
              updatedAt: new Date(),
            };
          }
          return comment;
        });
        return { ...discussion, comments: updatedComments };
      }
      return discussion;
    });
    setDiscussions(updatedDiscussions);
  };

  const { tf } = useEditorPlugin(CommentPlugin);

  // Replace to your own backend or refer to potion
  const isMyComment = currentUserId === comment.userId;

  const initialValue = comment.contentRich;

  const commentEditor = useCommentEditor(
    {
      id: comment.id,
      value: initialValue,
    },
    [initialValue],
  );

  const onCancel = () => {
    setEditingId(null);
    commentEditor.tf.replaceNodes(initialValue, {
      at: [],
      children: true,
    });
  };

  const onSave = () => {
    void updateComment({
      id: comment.id,
      contentRich: commentEditor.children,
      discussionId: comment.discussionId,
      isEdited: true,
    });
    setEditingId(null);
  };

  const onResolveComment = () => {
    void resolveDiscussion(comment.discussionId);
    tf.comment.unsetMark({ id: comment.discussionId });
  };

  const isFirst = index === 0;
  const isLast = index === discussionLength - 1;
  const isEditing = editingId && editingId === comment.id;

  const [hovering, setHovering] = React.useState(false);
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  return (
    <div
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
    >
      <div className="relative flex items-start gap-2.5">
        {/* === START CUSTOMIZATION ===
            Original rendered:
              <Avatar className="size-8">
                <AvatarImage alt={userInfo?.name} src={userInfo?.avatarUrl} />
                <AvatarFallback>{userInfo?.name?.[0]}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <h4 ...>{userInfo?.name}</h4>
                <div ...>{formatCommentDate(...)}{comment.isEdited && ...}</div>
              </div>
            Replaced with PersonPill, which already renders name + subheading. */}
        <PersonPill
          fullname={userInfo?.name}
          id={userInfo?.id ?? comment.userId}
          portrait={userInfo?.avatarUrl}
          subheading={
            formatCommentDate(new Date(comment.createdAt)) +
            (comment.isEdited ? ' (edited)' : '')
          }
        />
        {/* === END CUSTOMIZATION === */}

        {isMyComment && (hovering || dropdownOpen) && (
          <div className="absolute top-0 right-0 flex space-x-1">
            <CommentMoreDropdown
              onCloseAutoFocus={() => {
                setTimeout(() => {
                  commentEditor.tf.focus({ edge: 'endEditor' });
                }, 0);
              }}
              onRemoveComment={() => {
                if (discussionLength === 1) {
                  tf.comment.unsetMark({ id: comment.discussionId });
                  void removeDiscussion(comment.discussionId);
                }
              }}
              comment={comment}
              dropdownOpen={dropdownOpen}
              setDropdownOpen={setDropdownOpen}
              setEditingId={setEditingId}
            />
          </div>
        )}
      </div>

      {isFirst && showDocumentContent && (
        <div className="text-subtle-foreground relative mt-2 flex pl-[42px] text-sm">
          {discussionLength > 1 && (
            <div className="absolute top-[5px] left-4 h-full w-0.5 shrink-0 bg-muted" />
          )}
          <div className="bg-highlight my-px w-0.5 shrink-0" />
          {documentContent && <div className="ml-2">{documentContent}</div>}
        </div>
      )}

      <div className="relative mt-1.5 mb-3 pl-[42px]">
        {!isLast && (
          <div className="absolute top-0 left-4 h-full w-0.5 shrink-0 bg-muted" />
        )}
        <Plate readOnly={!isEditing} editor={commentEditor}>
          <EditorContainer variant="comment">
            <Editor
              variant="comment"
              className="w-auto grow text-sm leading-normal font-light text-foreground"
              onClick={() => onEditorClick?.()}
            />

            {isEditing && (
              <div className="ml-auto flex shrink-0 gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  className="size-[28px]"
                  onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                    e.stopPropagation();
                    void onCancel();
                  }}
                >
                  <div
                    className={`
                      flex size-5 shrink-0 items-center justify-center rounded-[50%] bg-primary/40
                    `}
                  >
                    <XIcon className="size-3 stroke-[3px] text-background" />
                  </div>
                </Button>

                <Button
                  size="icon"
                  variant="ghost"
                  onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                    e.stopPropagation();
                    void onSave();
                  }}
                >
                  <div
                    className={`
                      flex size-5 shrink-0 items-center justify-center rounded-[50%] bg-brand
                    `}
                  >
                    <CheckIcon className="size-3 stroke-[3px] text-background" />
                  </div>
                </Button>
              </div>
            )}
          </EditorContainer>
        </Plate>

        {isFirst && onReply && !isEditing && (
          <div className="mt-[7px] flex gap-4">
            <button
              className={`
                cursor-pointer border-0 bg-transparent p-0 text-[13px]! leading-[1.6]! font-semibold
                text-brand
                hover:underline
              `}
              onClick={onResolveComment}
              type="button"
            >
              Resolve
            </button>
            <button
              className={`
                cursor-pointer border-0 bg-transparent p-0 text-[13px]! leading-[1.6]! font-semibold
                text-brand
                hover:underline
              `}
              onClick={onReply}
              type="button"
            >
              Reply
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function CommentMoreDropdown(props: {
  comment: TComment;
  dropdownOpen: boolean;
  setDropdownOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setEditingId: React.Dispatch<React.SetStateAction<string | null>>;
  onCloseAutoFocus?: () => void;
  onRemoveComment?: () => void;
}) {
  const {
    comment,
    dropdownOpen,
    setDropdownOpen,
    setEditingId,
    onCloseAutoFocus,
    onRemoveComment,
  } = props;

  const { discussions, setDiscussions } = usePlatePlugins();

  const selectedEditCommentRef = React.useRef<boolean>(false);

  const onDeleteComment = React.useCallback(() => {
    if (!comment.id)
      // eslint-disable-next-line no-alert
      return alert('You are operating too quickly, please try again later.');

    // Find and update the discussion
    const updatedDiscussions = discussions.map((discussion) => {
      if (discussion.id !== comment.discussionId) {
        return discussion;
      }

      const commentIndex = discussion.comments.findIndex(
        (c) => c.id === comment.id,
      );
      if (commentIndex === -1) {
        return discussion;
      }

      return {
        ...discussion,
        comments: [
          ...discussion.comments.slice(0, commentIndex),
          ...discussion.comments.slice(commentIndex + 1),
        ],
      };
    });

    setDiscussions(updatedDiscussions);
    onRemoveComment?.();
  }, [
    comment.discussionId,
    comment.id,
    discussions,
    onRemoveComment,
    setDiscussions,
  ]);

  const onEditComment = React.useCallback(() => {
    selectedEditCommentRef.current = true;

    if (!comment.id)
      // eslint-disable-next-line no-alert
      return alert('You are operating too quickly, please try again later.');

    setEditingId(comment.id);
  }, [comment.id, setEditingId]);

  return (
    <DropdownMenu
      open={dropdownOpen}
      onOpenChange={setDropdownOpen}
      modal={false}
    >
      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
        <Button variant="ghost" className={cn('h-6 p-1 text-muted-foreground')}>
          <MoreHorizontalIcon className="size-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="w-48"
        onCloseAutoFocus={(e) => {
          if (selectedEditCommentRef.current) {
            onCloseAutoFocus?.();
            selectedEditCommentRef.current = false;
          }

          return e.preventDefault();
        }}
      >
        <DropdownMenuGroup>
          <DropdownMenuItem onClick={onEditComment}>
            <PencilIcon className="size-4" />
            Edit comment
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onDeleteComment}>
            <TrashIcon className="size-4" />
            Delete comment
          </DropdownMenuItem>
        </DropdownMenuGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

const useCommentEditor = (
  options: Omit<CreatePlateEditorOptions, 'plugins'> = {},
  deps: any[] = [],
) => {
  const { commentEditorPlugins } = usePlatePlugins();
  const commentEditor = usePlateEditor(
    {
      id: 'comment',
      plugins: commentEditorPlugins ?? BasicMarksKit,
      value: [],
      ...options,
    },
    deps,
  );

  return commentEditor;
};

export interface CommentCreateFormHandle {
  focus: () => void;
}

export const CommentCreateForm = React.forwardRef<
  CommentCreateFormHandle,
  {
    autoFocus?: boolean;
    className?: string;
    discussionId?: string;
    focusOnMount?: boolean;
  }
>(function CommentCreateForm(
  {
    autoFocus = false,
    className,
    discussionId: discussionIdProp,
    focusOnMount = false,
  },
  ref,
) {
  const editor = useEditorRef();
  const commentId = useCommentId();
  const discussionId = discussionIdProp ?? commentId;
  const { currentUserId, discussions, setDiscussions } = usePlatePlugins();
  const [commentValue, setCommentValue] = React.useState<Value | undefined>();
  const commentContent = React.useMemo(
    () =>
      commentValue
        ? NodeApi.string({ children: commentValue, type: KEYS.p })
        : '',
    [commentValue],
  );
  const commentEditor = useCommentEditor();

  React.useEffect(() => {
    if (commentEditor && focusOnMount) {
      commentEditor.tf.focus();
    }
  }, [commentEditor, focusOnMount]);

  React.useImperativeHandle(
    ref,
    () => ({
      focus: () => {
        commentEditor.tf.focus({ edge: 'endEditor' });
      },
    }),
    [commentEditor],
  );

  const onAddComment = React.useCallback(async () => {
    if (!commentValue || !currentUserId) return;

    commentEditor.tf.reset();

    if (discussionId) {
      // Get existing discussion
      const discussion = discussions.find((d) => d.id === discussionId);
      if (!discussion) {
        // Mock creating suggestion
        const newDiscussion: TDiscussion = {
          id: discussionId,
          comments: [
            {
              id: nanoid(),
              contentRich: commentValue,
              createdAt: new Date(),
              discussionId,
              isEdited: false,
              userId: currentUserId,
            },
          ],
          createdAt: new Date(),
          isResolved: false,
          userId: currentUserId,
        };

        setDiscussions([...discussions, newDiscussion]);
        return;
      }

      // Create reply comment
      const comment: TComment = {
        id: nanoid(),
        contentRich: commentValue,
        createdAt: new Date(),
        discussionId,
        isEdited: false,
        userId: currentUserId,
      };

      // Add reply to discussion comments
      const updatedDiscussion = {
        ...discussion,
        comments: [...discussion.comments, comment],
      };

      // Filter out old discussion and add updated one
      const updatedDiscussions = discussions
        .filter((d) => d.id !== discussionId)
        .concat(updatedDiscussion);

      setDiscussions(updatedDiscussions);

      return;
    }

    const commentsNodeEntry = editor
      .getApi(CommentPlugin)
      .comment.nodes({ at: [], isDraft: true });

    if (commentsNodeEntry.length === 0) return;

    const documentContent = commentsNodeEntry
      .map(([node]) => node.text)
      .join('');

    const _discussionId = nanoid();
    // Mock creating new discussion
    const newDiscussion: TDiscussion = {
      id: _discussionId,
      comments: [
        {
          id: nanoid(),
          contentRich: commentValue,
          createdAt: new Date(),
          discussionId: _discussionId,
          isEdited: false,
          userId: currentUserId,
        },
      ],
      createdAt: new Date(),
      documentContent,
      isResolved: false,
      userId: currentUserId,
    };

    setDiscussions([...discussions, newDiscussion]);

    const id = newDiscussion.id;

    commentsNodeEntry.forEach(([, path]) => {
      editor.tf.setNodes(
        {
          [getCommentKey(id)]: true,
        },
        { at: path, split: true },
      );
      editor.tf.unsetNodes([getDraftCommentKey()], { at: path });
    });
  }, [
    commentValue,
    commentEditor.tf,
    currentUserId,
    discussionId,
    editor,
    discussions,
    setDiscussions,
  ]);

  return (
    <div className={cn('flex w-full', className)}>
      <div className="relative flex grow gap-2">
        <Plate
          onChange={({ value }) => {
            setCommentValue(value);
          }}
          editor={commentEditor}
        >
          <EditorContainer
            className={`
              min-h-11 items-center rounded-full border border-border bg-muted py-1.5 pr-2 pl-4
              shadow-inner shadow-slate-200/40
            `}
            variant="comment"
          >
            <Editor
              variant="comment"
              className=""
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  onAddComment();
                }
              }}
              placeholder={discussionId ? 'Reply to thread...' : 'Reply...'}
              autoComplete="off"
              // === START CUSTOMIZATION ===
              // Opt-in via the `autoFocus` prop, only set when explicitly
              // requested by the caller (e.g. right after clicking "Reply"),
              // not on page load.
              // eslint-disable-next-line jsx-a11y/no-autofocus
              autoFocus={autoFocus}
              // === END CUSTOMIZATION ===
            />

            <Button
              size="icon"
              variant="ghost"
              className={`
                absolute right-2 bottom-1.5 ml-auto size-8 shrink-0 text-muted-foreground
                hover:text-brand
              `}
              disabled={commentContent.trim().length === 0}
              onClick={(e) => {
                e.stopPropagation();
                onAddComment();
              }}
            >
              <div className="flex size-6 items-center justify-center rounded-full">
                <SendIcon />
              </div>
            </Button>
          </EditorContainer>
        </Plate>
      </div>
    </div>
  );
});

export const formatCommentDate = (date: Date) => {
  // Removed to not use date-fns - improve if needed.
  // Format dates older than 2 days with MM/dd/yyyy pattern
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const year = date.getFullYear();
  return `${month}/${day}/${year}`;
};
