import { useCallback } from 'react';
import { flattenToAppURL } from '@plone/volto/helpers/Url/Url';
import { withBlockExtensions } from '@plone/volto/helpers/Extensions';
import config from '@plone/volto/registry';
import { ImageInput } from '@plone/volto/components/manage/Widgets/ImageWidget';
import Caption from '@kitconcept/volto-light-theme/components/Caption/Caption';

function Edit(props) {
  const { data, block } = props;
  const Image = config.getComponent({ name: 'Image' }).component;

  const onSelectItem = useCallback(
    (url, item) => {
      const dataAdapter = props.blocksConfig[props.data['@type']].dataAdapter;
      dataAdapter({
        block: props.block,
        data: props.data,
        onChangeBlock: props.onChangeBlock,
        id: 'url',
        value: url,
        item,
      });
    },
    [props],
  );

  const handleChange = useCallback(
    async (id, image, { title, image_field, image_scales } = {}) => {
      const url = Array.isArray(image)
        ? image?.[0]?.['@id']
        : image
          ? image['@id'] || image
          : '';

      props.onChangeBlock(props.block, {
        ...props.data,
        url: flattenToAppURL(url),
        image_field,
        image_scales,
        alt: props.data.alt || title || '',
      });
    },
    [props],
  );

  return (
    <>
      {data.url ? (
        <figure>
          <Image
            item={
              data.image_scales
                ? {
                    '@id': data.url,
                    image_field: data.image_field,
                    image_scales: data.image_scales,
                  }
                : undefined
            }
            src={data.image_scales ? undefined : data.url}
            sizes={config.blocks.blocksConfig.image.getSizes(data)}
            alt={data.alt || ''}
            loading="lazy"
            responsive={true}
          />
          <Caption
            title={data.title}
            description={data.description}
            credit={data?.copyright_and_sources ?? data.credit?.data}
          />
        </figure>
      ) : (
        <ImageInput
          onChange={handleChange}
          placeholderLinkInput={data.placeholder}
          block={block}
          id={block}
          objectBrowserPickerType={'image'}
          onSelectItem={onSelectItem}
        />
      )}
    </>
  );
}

export default withBlockExtensions(Edit);
